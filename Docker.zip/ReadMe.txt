
	Docker ReadMe.


	Docker.exe is the Application Builder.

	DockerHelp.exe is both an example of an Application Built
	with Docker.exe, and a help file for it.

	RcDataPE.exe is the generic Application, loaded inside
	Docker.exe RC_DATA Resources, that Docker uses to rebuild
	the outputed Applications.

	Chunks.txt is the organisation file and all rtf files are
	the ones used to rebuild DockerHelp.exe.

	Docker.bkm is a BookMark File that SpAsm Assembler will
	use if you run SpAsm to read Docker.exe Sources.

	http://betov.free.fr/SpAsm.html

	betov@free.fr
	